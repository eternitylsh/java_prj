
public class Test7 {
	static int speed;
	String color;
	
	public int speedUp(int speed) {
		return this.speed += speed;
	}
	
	public int speedDown(int speed) {
		return this.speed -= speed;
	}
}
