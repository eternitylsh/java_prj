
public class Test9 {
	public float add(float n1, float n2) {
		return n1 + n2;
	}
	
	public int add(int n1, int n2) {
		return n1 + n2;
	}
}
